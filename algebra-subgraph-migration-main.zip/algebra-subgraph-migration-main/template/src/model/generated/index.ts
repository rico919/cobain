export * from "./entity.model"
